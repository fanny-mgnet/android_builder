# Quick Start — 5 Minutes to Priya

## Prerequisites
- Android Studio (Hedgehog 2023.1+ recommended)
- Android phone with WhatsApp installed
- Free Groq account: https://console.groq.com

## Steps

### 1. Open in Android Studio
File → Open → select the `priya-android` folder

### 2. Get your free Groq API key
- Go to https://console.groq.com/keys
- Sign up (free, no credit card)
- Create a key — it starts with `gsk_`

### 3. Build & Install
Click the green ▶ Run button in Android Studio
(Or: `./gradlew installDebug` in terminal)

### 4. Setup on your phone
1. Open "Priya Auto Responder" app
2. Tap "Open Accessibility Settings" → find "Priya Auto Responder" → enable it
3. Paste your Groq API key → tap "Save Key"
4. Grant microphone permission when prompted
5. Tap "Test Priya's Voice" to confirm audio works

### 5. Test it!
Have someone call your WhatsApp number.
Priya will answer and respond automatically.

---

## Customize Priya's Personality
Tap "Advanced Settings" and edit the system prompt to change her personality,
behavior, or add product/business-specific knowledge.

Example custom prompt:
```
You are Priya, customer support for TechCorp. 
You help customers with software billing questions.
Our support hours are 9am-6pm IST.
For urgent issues, escalate to support@techcorp.com.
Your greeting: "Hi, this is Priya from TechCorp support. How can I assist you?"
```
