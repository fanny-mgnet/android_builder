# Priya — AI WhatsApp Auto-Responder (Android)

An Android app that automatically answers incoming WhatsApp calls and responds on your behalf using an AI persona named **Priya**, a friendly customer support agent.

---

## How It Works

```
WhatsApp Incoming Call
        │
        ▼
[AccessibilityService] ──── detects call screen ──→ clicks "Answer" button
        │
        ▼
[CallProcessingService] starts
        │
        ├─ Plays greeting: "Hello! This is Priya. How can I help you today?"
        │
        ▼
[AudioRecord] ──── records caller's voice ──→ saves as .wav
        │
        ▼
[Groq API - Whisper] ──── Speech-to-Text transcription (FREE tier)
        │
        ▼
[Groq API - LLaMA 3] ──── LLM generates Priya's response (FREE tier)
        │
        ▼
[Android TTS] ──── text-to-speech ──→ plays response to caller
        │
        └──────────────────── loops back to listen again
```

---

## Requirements

- Android 8.0+ (API 26)
- A free [Groq API key](https://console.groq.com/keys) (no credit card required)
- WhatsApp installed on the device
- Microphone permission
- Accessibility Service enabled for this app

---

## Getting Started

### 1. Clone and Open in Android Studio

```bash
git clone <this-repo>
```

Open the `priya-android/` folder in **Android Studio Hedgehog or newer**.

### 2. Build and Install

```bash
./gradlew installDebug
```

Or use `Build > Run` in Android Studio.

### 3. Configure the App

1. **Enable Accessibility Service**
   - Open the app → tap "Open Accessibility Settings"
   - Find "Priya Auto Responder" → enable it
   - Grant all requested permissions

2. **Add Your Groq API Key**
   - Visit [console.groq.com/keys](https://console.groq.com/keys)
   - Create a free account and generate an API key (starts with `gsk_`)
   - Paste it into the app and tap "Save Key"

3. **Test Priya's Voice**
   - Tap "Test Priya's Voice" to hear how she sounds

### 4. Make a Test Call

Have someone WhatsApp-call your device. The app will:
- Auto-answer after ~2 seconds
- Greet the caller as Priya
- Listen, transcribe, respond, and loop

---

## Architecture

### `WhatsAppAccessibilityService.kt`
- Registered as an Android Accessibility Service
- Monitors all events from `com.whatsapp` package
- Detects the incoming call screen by scanning the view hierarchy for call-related UI text
- Clicks the "Accept" / "Answer" button automatically
- Broadcasts intents to trigger `CallProcessingService`

### `CallProcessingService.kt`
- Runs as a **foreground service** (MICROPHONE type) — required for background audio recording on Android 10+
- Records caller audio using `AudioRecord` (raw PCM → WAV)
  - Silence detection stops recording early when the caller finishes speaking
- Sends WAV to **Groq Whisper** (`whisper-large-v3`) for transcription
- Sends transcript to **Groq LLaMA 3** for response generation
- Plays response via Android's built-in **TextToSpeech** engine
- Maintains full conversation history for multi-turn context

### `GroqApiClient.kt`
- Handles both STT (Groq's Whisper endpoint) and LLM (chat completions)
- Free tier limits: 14,400 audio seconds/day + 30,000 LLM tokens/minute
- Uses OkHttp for networking with 60s timeouts

### `AppPreferences.kt`
- SharedPreferences wrapper for all user settings
- Stores: API key, personality prompt, model names, timing settings

---

## Configuration Options

| Setting | Default | Description |
|---------|---------|-------------|
| Groq API Key | (required) | Free key from console.groq.com |
| Answer Delay | 2 seconds | Time to wait before auto-answering |
| Listen Duration | 8 seconds | Max time to record per turn |
| LLM Model | `llama3-8b-8192` | Free Groq LLM model |
| STT Model | `whisper-large-v3` | Free Groq Whisper model |
| Personality | Priya prompt | Customize Priya's behavior |

### Alternative Free Groq Models

**LLM models (free tier):**
- `llama3-8b-8192` — fastest, great for support
- `llama3-70b-8192` — higher quality, slower
- `mixtral-8x7b-32768` — longer context window
- `gemma2-9b-it` — Google's model

**STT models (free tier):**
- `whisper-large-v3` — best accuracy
- `whisper-large-v3-turbo` — 4x faster, slightly less accurate
- `distil-whisper-large-v3-en` — English-only, fastest

---

## Priya's Default Personality

```
You are Priya, a friendly and helpful customer support agent.
Your greeting is: "Hello! This is Priya. How can I help you today?"
Keep responses concise and natural for phone conversation.
Speak warmly but professionally.
```

You can fully customize this in Advanced Settings.

---

## Important Notes

### WhatsApp Call Screen Detection
WhatsApp changes its UI layouts frequently. If the auto-answer stops working:
1. Enable Android Developer Options → "Show Layout Bounds" or use Android Studio Layout Inspector
2. Look for the view hierarchy of the incoming call screen
3. Update `ANSWER_BUTTON_TEXTS` and `INCOMING_CALL_TEXTS` in `WhatsAppAccessibilityService.kt`

### Audio Routing
The app uses `VOICE_COMMUNICATION` audio source which captures the microphone audio. During a WhatsApp call, the caller's voice comes through the earpiece/speaker and is captured by the microphone. This is the standard approach for apps that can't directly access call audio streams (which requires carrier integration).

### Silence Detection
The `SILENCE_THRESHOLD` (500 PCM amplitude units) and `SILENCE_FRAMES_TO_STOP` (30 frames ≈ 1.5 seconds) control when Priya stops listening. Adjust these in `CallProcessingService.kt` if needed:
- Lower threshold = more sensitive (stops sooner)
- Higher threshold = less sensitive (waits longer)

### Battery & Background
Android may kill background services on some OEMs (Samsung, Xiaomi, etc.). To prevent this:
- Add the app to battery optimization exclusion list
- Enable "Auto-start" permission if your device has it
- Keep the app in the foreground notification

---

## Permissions Required

| Permission | Purpose |
|-----------|---------|
| `RECORD_AUDIO` | Capture caller's voice |
| `INTERNET` | Groq API calls |
| `FOREGROUND_SERVICE` | Keep service running |
| `FOREGROUND_SERVICE_MICROPHONE` | Background microphone access |
| `POST_NOTIFICATIONS` | Show active call notification |
| `BIND_ACCESSIBILITY_SERVICE` | Monitor WhatsApp UI |
| `MODIFY_AUDIO_SETTINGS` | Configure audio routing |

---

## Troubleshooting

**"Auto-answer not working"**
- Make sure Accessibility Service is enabled (check Settings > Accessibility)
- WhatsApp may have updated its UI — check the layout with Layout Inspector

**"Transcription failing"**
- Check your Groq API key is valid
- Check internet connection
- Verify you haven't exceeded free tier limits (14,400 audio seconds/day)

**"No voice in recordings"**
- Check `RECORD_AUDIO` permission is granted
- Try adjusting `SILENCE_THRESHOLD` to a lower value

**"App killed in background"**
- Disable battery optimization for this app
- On Samsung: Settings > Device Care > Battery > App Power Management > Add to exceptions
- On Xiaomi/MIUI: Settings > Apps > Manage Apps > Priya > Battery > No Restrictions

---

## License

MIT License — free to use and modify.
