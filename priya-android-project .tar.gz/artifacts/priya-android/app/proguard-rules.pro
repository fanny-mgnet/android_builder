-keep class com.priya.autoresponder.** { *; }
-keepclassmembers class ** {
    @android.webkit.JavascriptInterface <methods>;
}
