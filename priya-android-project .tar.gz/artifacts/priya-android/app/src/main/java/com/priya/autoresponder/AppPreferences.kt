package com.priya.autoresponder

import android.content.Context
import android.content.SharedPreferences

object AppPreferences {

    private const val PREFS_NAME = "priya_prefs"
    private const val KEY_GROQ_API_KEY = "groq_api_key"
    private const val KEY_PERSONALITY = "personality"
    private const val KEY_ANSWER_DELAY = "answer_delay"
    private const val KEY_LISTEN_DURATION = "listen_duration"
    private const val KEY_LLM_MODEL = "llm_model"
    private const val KEY_STT_MODEL = "stt_model"

    private const val DEFAULT_PERSONALITY = """You are Priya, a friendly and helpful customer support agent. Your greeting is: "Hello! This is Priya. How can I help you today?" Keep responses concise and natural for phone conversation. Speak warmly but professionally. If you cannot help with something, politely say so and offer alternatives."""

    private const val DEFAULT_LLM_MODEL = "llama3-8b-8192"
    private const val DEFAULT_STT_MODEL = "whisper-large-v3"
    private const val DEFAULT_ANSWER_DELAY = 2
    private const val DEFAULT_LISTEN_DURATION = 8

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getGroqApiKey(context: Context): String =
        prefs(context).getString(KEY_GROQ_API_KEY, "") ?: ""

    fun setGroqApiKey(context: Context, key: String) =
        prefs(context).edit().putString(KEY_GROQ_API_KEY, key).apply()

    fun getPersonality(context: Context): String =
        prefs(context).getString(KEY_PERSONALITY, DEFAULT_PERSONALITY) ?: DEFAULT_PERSONALITY

    fun setPersonality(context: Context, personality: String) =
        prefs(context).edit().putString(KEY_PERSONALITY, personality).apply()

    fun getAnswerDelay(context: Context): Int =
        prefs(context).getInt(KEY_ANSWER_DELAY, DEFAULT_ANSWER_DELAY)

    fun setAnswerDelay(context: Context, delay: Int) =
        prefs(context).edit().putInt(KEY_ANSWER_DELAY, delay).apply()

    fun getListenDuration(context: Context): Int =
        prefs(context).getInt(KEY_LISTEN_DURATION, DEFAULT_LISTEN_DURATION)

    fun setListenDuration(context: Context, duration: Int) =
        prefs(context).edit().putInt(KEY_LISTEN_DURATION, duration).apply()

    fun getLlmModel(context: Context): String =
        prefs(context).getString(KEY_LLM_MODEL, DEFAULT_LLM_MODEL) ?: DEFAULT_LLM_MODEL

    fun setLlmModel(context: Context, model: String) =
        prefs(context).edit().putString(KEY_LLM_MODEL, model).apply()

    fun getSttModel(context: Context): String =
        prefs(context).getString(KEY_STT_MODEL, DEFAULT_STT_MODEL) ?: DEFAULT_STT_MODEL

    fun setSttModel(context: Context, model: String) =
        prefs(context).edit().putString(KEY_STT_MODEL, model).apply()
}
