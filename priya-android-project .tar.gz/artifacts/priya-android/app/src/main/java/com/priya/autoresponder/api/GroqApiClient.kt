package com.priya.autoresponder.api

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Client for Groq's free-tier API.
 * Handles both:
 *   - Speech-to-Text (Whisper via Groq's audio transcription endpoint)
 *   - LLM chat completions (Llama3 etc.)
 */
class GroqApiClient(private val apiKey: String) {

    companion object {
        private const val TAG = "GroqApiClient"
        private const val BASE_URL = "https://api.groq.com/openai/v1"
        private const val TIMEOUT_SECONDS = 60L
    }

    private val gson = Gson()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .readTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .writeTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .build()

    /**
     * Transcribe audio file using Groq's Whisper endpoint (free tier).
     * @param audioFile The recorded audio file (.wav or .m4a)
     * @param model The Whisper model to use (e.g. "whisper-large-v3")
     * @return Transcribed text or null on error
     */
    fun transcribeAudio(audioFile: File, model: String = "whisper-large-v3"): String? {
        if (!audioFile.exists() || audioFile.length() == 0L) {
            Log.e(TAG, "Audio file does not exist or is empty: ${audioFile.path}")
            return null
        }

        val mimeType = when {
            audioFile.name.endsWith(".wav") -> "audio/wav"
            audioFile.name.endsWith(".m4a") -> "audio/mp4"
            audioFile.name.endsWith(".mp3") -> "audio/mpeg"
            else -> "audio/wav"
        }

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", audioFile.name, audioFile.asRequestBody(mimeType.toMediaType()))
            .addFormDataPart("model", model)
            .addFormDataPart("response_format", "text")
            .addFormDataPart("language", "en")
            .build()

        val request = Request.Builder()
            .url("$BASE_URL/audio/transcriptions")
            .header("Authorization", "Bearer $apiKey")
            .post(requestBody)
            .build()

        return try {
            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val text = response.body?.string()?.trim()
                Log.d(TAG, "Transcription: $text")
                text
            } else {
                val errorBody = response.body?.string()
                Log.e(TAG, "Transcription failed: ${response.code} — $errorBody")
                null
            }
        } catch (e: IOException) {
            Log.e(TAG, "Transcription network error", e)
            null
        }
    }

    /**
     * Generate a chat response using Groq's LLM (free tier).
     * @param systemPrompt Priya's personality/system instructions
     * @param conversationHistory List of prior messages (alternating user/assistant)
     * @param userMessage The caller's latest transcribed message
     * @param model The LLM model to use (e.g. "llama3-8b-8192")
     * @return Generated response text or null on error
     */
    fun generateResponse(
        systemPrompt: String,
        conversationHistory: List<ChatMessage>,
        userMessage: String,
        model: String = "llama3-8b-8192"
    ): String? {
        val messages = mutableListOf<JsonObject>()

        // System message
        messages.add(JsonObject().apply {
            addProperty("role", "system")
            addProperty("content", systemPrompt)
        })

        // Conversation history
        conversationHistory.forEach { msg ->
            messages.add(JsonObject().apply {
                addProperty("role", msg.role)
                addProperty("content", msg.content)
            })
        }

        // Current user message
        messages.add(JsonObject().apply {
            addProperty("role", "user")
            addProperty("content", userMessage)
        })

        val requestJson = JsonObject().apply {
            addProperty("model", model)
            add("messages", gson.toJsonTree(messages))
            addProperty("max_tokens", 256)
            addProperty("temperature", 0.7)
            addProperty("stream", false)
        }

        val requestBody = requestJson.toString()
            .toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url("$BASE_URL/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json")
            .post(requestBody)
            .build()

        return try {
            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val responseBody = response.body?.string() ?: return null
                val json = JsonParser.parseString(responseBody).asJsonObject
                val content = json
                    .getAsJsonArray("choices")
                    ?.get(0)?.asJsonObject
                    ?.getAsJsonObject("message")
                    ?.get("content")?.asString
                    ?.trim()
                Log.d(TAG, "LLM response: $content")
                content
            } else {
                val errorBody = response.body?.string()
                Log.e(TAG, "LLM call failed: ${response.code} — $errorBody")
                null
            }
        } catch (e: IOException) {
            Log.e(TAG, "LLM network error", e)
            null
        }
    }

    data class ChatMessage(
        val role: String,
        val content: String
    )
}
