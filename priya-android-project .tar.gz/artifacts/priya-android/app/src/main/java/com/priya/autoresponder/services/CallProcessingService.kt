package com.priya.autoresponder.services

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import com.priya.autoresponder.AppPreferences
import com.priya.autoresponder.R
import com.priya.autoresponder.api.GroqApiClient
import com.priya.autoresponder.ui.MainActivity
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.sqrt

/**
 * Foreground service that manages the full call processing pipeline:
 *
 *  1. Records the caller's audio using AudioRecord (raw PCM → WAV)
 *  2. Sends the audio to Groq Whisper for transcription (STT)
 *  3. Sends the transcript to Groq LLaMA for a response (LLM)
 *  4. Plays the response using Android TextToSpeech (TTS)
 *  5. Loops back to step 1 to continue the conversation
 */
class CallProcessingService : Service() {

    companion object {
        private const val TAG = "CallProcessingService"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "priya_call_channel"

        // Audio recording config
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val SILENCE_THRESHOLD = 500.0
        private const val SILENCE_FRAMES_TO_STOP = 30

        // Status broadcast constants
        const val ACTION_STATUS = "com.priya.autoresponder.STATUS_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_TEXT = "text"
    }

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var callJob: Job? = null
    private var isCallActive = false

    private val conversationHistory = mutableListOf<GroqApiClient.ChatMessage>()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        initTts()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            WhatsAppAccessibilityService.ACTION_CALL_ANSWERED -> {
                startForeground(NOTIFICATION_ID, buildNotification("Handling WhatsApp call…"))
                startCallProcessing()
            }
            WhatsAppAccessibilityService.ACTION_CALL_ENDED -> {
                endCallProcessing()
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ─── TTS ──────────────────────────────────────────────────────────────────

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale.US)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Log.e(TAG, "TTS language not supported")
                } else {
                    isTtsReady = true
                    tts?.setSpeechRate(0.9f)
                    tts?.setPitch(1.05f)
                    Log.i(TAG, "TTS initialized")
                }
            } else {
                Log.e(TAG, "TTS init failed: $status")
            }
        }
    }

    // ─── Call Processing Loop ─────────────────────────────────────────────────

    private fun startCallProcessing() {
        if (isCallActive) return
        isCallActive = true
        conversationHistory.clear()

        callJob = serviceScope.launch {
            val apiKey = AppPreferences.getGroqApiKey(this@CallProcessingService)
            if (apiKey.isBlank()) {
                broadcastStatus("error", "No API key configured.")
                stopSelf()
                return@launch
            }

            val groq = GroqApiClient(apiKey)
            val systemPrompt = AppPreferences.getPersonality(this@CallProcessingService)
            val llmModel = AppPreferences.getLlmModel(this@CallProcessingService)
            val sttModel = AppPreferences.getSttModel(this@CallProcessingService)
            val listenDuration = AppPreferences.getListenDuration(this@CallProcessingService)

            delay(800)
            val greeting = "Hello! This is Priya. How can I help you today?"
            broadcastStatus("speaking", greeting)
            speakAndWait(greeting)

            while (isCallActive && isActive) {
                broadcastStatus("recording", "Listening to caller…")
                updateNotification("Listening…")
                val audioFile = recordCallerAudio(listenDuration)

                if (audioFile == null || !isCallActive) break

                broadcastStatus("transcribing", "Transcribing…")
                updateNotification("Transcribing speech…")
                val transcript = groq.transcribeAudio(audioFile, sttModel)
                audioFile.delete()

                if (transcript.isNullOrBlank()) continue

                broadcastStatus("transcribed", "Caller: $transcript")
                conversationHistory.add(GroqApiClient.ChatMessage("user", transcript))

                broadcastStatus("generating", "Thinking…")
                updateNotification("Generating response…")
                val response = groq.generateResponse(
                    systemPrompt = systemPrompt,
                    conversationHistory = conversationHistory.dropLast(1),
                    userMessage = transcript,
                    model = llmModel
                )

                if (response.isNullOrBlank()) {
                    speakAndWait("I'm sorry, I didn't quite catch that. Could you repeat?")
                    continue
                }

                conversationHistory.add(GroqApiClient.ChatMessage("assistant", response))
                broadcastStatus("speaking", "Priya: $response")
                updateNotification("Speaking…")
                speakAndWait(response)
            }

            broadcastStatus("idle", "Call ended")
            stopSelf()
        }
    }

    private fun endCallProcessing() {
        isCallActive = false
        callJob?.cancel()
        tts?.stop()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ─── Audio Recording ──────────────────────────────────────────────────────

    @SuppressLint("MissingPermission")
    private fun recordCallerAudio(maxDurationSeconds: Int): File? {
        val bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        if (bufferSize == AudioRecord.ERROR || bufferSize == AudioRecord.ERROR_BAD_VALUE) {
            Log.e(TAG, "Invalid AudioRecord buffer size")
            return null
        }

        val audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            SAMPLE_RATE,
            CHANNEL_CONFIG,
            AUDIO_FORMAT,
            bufferSize * 4
        )

        if (audioRecord.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "AudioRecord failed to initialize")
            audioRecord.release()
            return null
        }

        val wavFile = File(cacheDir, "caller_${System.currentTimeMillis()}.wav")
        val allPcmData = mutableListOf<ByteArray>()
        val buffer = ByteArray(bufferSize)
        val maxFrames = (SAMPLE_RATE * maxDurationSeconds) / (bufferSize / 2)
        var silenceCount = 0
        var totalFrames = 0
        var hasVoice = false

        audioRecord.startRecording()

        try {
            while (totalFrames < maxFrames && isCallActive) {
                val bytesRead = audioRecord.read(buffer, 0, bufferSize)
                if (bytesRead <= 0) continue

                val chunk = buffer.copyOf(bytesRead)
                allPcmData.add(chunk)
                totalFrames++

                val rms = calculateRms(chunk)
                if (rms > SILENCE_THRESHOLD) {
                    hasVoice = true
                    silenceCount = 0
                } else {
                    silenceCount++
                }

                if (hasVoice && silenceCount > SILENCE_FRAMES_TO_STOP) break
            }
        } finally {
            audioRecord.stop()
            audioRecord.release()
        }

        if (!hasVoice || allPcmData.isEmpty()) return null

        val pcmBytes = allPcmData.reduce { acc, bytes -> acc + bytes }
        writeWavFile(wavFile, pcmBytes)
        return wavFile
    }

    private fun calculateRms(buffer: ByteArray): Double {
        val shorts = buffer.size / 2
        if (shorts == 0) return 0.0
        var sum = 0.0
        for (i in 0 until shorts) {
            val sample = ByteBuffer.wrap(buffer, i * 2, 2)
                .order(ByteOrder.LITTLE_ENDIAN)
                .short.toDouble()
            sum += sample * sample
        }
        return sqrt(sum / shorts)
    }

    private fun writeWavFile(file: File, pcmData: ByteArray) {
        val numChannels: Short = 1
        val bitsPerSample: Short = 16
        val byteRate = SAMPLE_RATE * numChannels * bitsPerSample / 8
        val blockAlign: Short = (numChannels * bitsPerSample / 8).toShort()
        val dataSize = pcmData.size

        FileOutputStream(file).use { fos ->
            fos.write("RIFF".toByteArray())
            fos.write(intToBytes(dataSize + 36))
            fos.write("WAVE".toByteArray())
            fos.write("fmt ".toByteArray())
            fos.write(intToBytes(16))
            fos.write(shortToBytes(1.toShort()))     // PCM format
            fos.write(shortToBytes(numChannels))
            fos.write(intToBytes(SAMPLE_RATE))
            fos.write(intToBytes(byteRate))
            fos.write(shortToBytes(blockAlign))
            fos.write(shortToBytes(bitsPerSample))
            fos.write("data".toByteArray())
            fos.write(intToBytes(dataSize))
            fos.write(pcmData)
        }
    }

    private fun intToBytes(value: Int): ByteArray =
        ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value).array()

    private fun shortToBytes(value: Short): ByteArray =
        ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(value).array()

    // ─── TTS Speak & Wait ─────────────────────────────────────────────────────

    private suspend fun speakAndWait(text: String) {
        if (!isTtsReady) { delay(2000); return }

        val done = CompletableDeferred<Unit>()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { done.complete(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { done.complete(Unit) }
        })

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "priya_${System.currentTimeMillis()}")
        withTimeoutOrNull(30_000L) { done.await() }
        delay(300)
    }

    // ─── Notification ─────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(text))
    }

    // ─── Broadcast ────────────────────────────────────────────────────────────

    private fun broadcastStatus(status: String, text: String = "") {
        sendBroadcast(Intent(ACTION_STATUS).apply {
            `package` = packageName
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_TEXT, text)
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        isCallActive = false
        serviceScope.cancel()
        tts?.stop()
        tts?.shutdown()
    }
}
