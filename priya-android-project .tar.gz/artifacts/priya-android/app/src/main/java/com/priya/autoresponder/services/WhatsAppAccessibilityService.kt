package com.priya.autoresponder.services

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * AccessibilityService that monitors WhatsApp for incoming voice/video calls
 * and automatically clicks the "Answer" button.
 */
class WhatsAppAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "WhatsAppA11yService"

        private val WHATSAPP_PACKAGES = setOf(
            "com.whatsapp",
            "com.whatsapp.w4b"
        )

        private val INCOMING_CALL_TEXTS = setOf(
            "incoming voice call",
            "incoming video call",
            "whatsapp voice call",
            "whatsapp video call",
            "voice call",
        )

        private val ANSWER_BUTTON_TEXTS = setOf(
            "accept",
            "answer",
            "answering",
        )

        const val ACTION_CALL_ANSWERED = "com.priya.autoresponder.CALL_ANSWERED"
        const val ACTION_CALL_ENDED = "com.priya.autoresponder.CALL_ENDED"

        private const val DEBOUNCE_MS = 3000L
    }

    private var lastAnswerTime = 0L
    private var callActive = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i(TAG, "Priya Accessibility Service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return

        val pkg = event.packageName?.toString() ?: return
        if (pkg !in WHATSAPP_PACKAGES) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> handleEvent(event)
            else -> { /* ignore */ }
        }
    }

    private fun handleEvent(event: AccessibilityEvent) {
        val now = System.currentTimeMillis()
        val windowText = event.text?.joinToString(" ")?.lowercase() ?: ""
        val rootNode = rootInActiveWindow ?: return

        try {
            val isCallScreen = isIncomingCallScreen(rootNode, windowText)

            if (isCallScreen && !callActive) {
                if (now - lastAnswerTime > DEBOUNCE_MS) {
                    Log.i(TAG, "Incoming WhatsApp call detected!")
                    broadcastSimpleStatus("incoming_call")

                    val delayMs = AppPreferencesAccessor.getAnswerDelayMs(this)
                    Thread.sleep(delayMs)

                    if (clickAnswerButton(rootNode)) {
                        lastAnswerTime = now
                        callActive = true
                        Log.i(TAG, "Call answered")
                        broadcastCallAnswered()
                    }
                }
            } else if (callActive && isCallEnded(windowText)) {
                Log.i(TAG, "Call ended")
                callActive = false
                broadcastCallEnded()
            }
        } finally {
            rootNode.recycle()
        }
    }

    private fun isIncomingCallScreen(root: AccessibilityNodeInfo, windowText: String): Boolean {
        for (keyword in INCOMING_CALL_TEXTS) {
            if (windowText.contains(keyword)) return true
        }

        val allText = collectAllNodeText(root)
        for (keyword in INCOMING_CALL_TEXTS) {
            if (allText.any { it.lowercase().contains(keyword) }) return true
        }

        val hasDecline = findNodeByText(root, "decline") != null ||
                findNodeByText(root, "reject") != null
        val hasAnswer = findAnswerButton(root) != null
        return hasDecline && hasAnswer
    }

    private fun clickAnswerButton(root: AccessibilityNodeInfo): Boolean {
        val answerNode = findAnswerButton(root)
        return if (answerNode != null) {
            val result = answerNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            Log.i(TAG, "Answer button click: $result")
            result
        } else {
            val byDesc = findNodeByContentDesc(root, "accept")
                ?: findNodeByContentDesc(root, "answer")
            byDesc?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: run {
                Log.w(TAG, "Answer button not found")
                false
            }
        }
    }

    private fun findAnswerButton(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (text in ANSWER_BUTTON_TEXTS) {
            val node = findNodeByText(root, text) ?: findNodeByContentDesc(root, text)
            if (node != null && node.isClickable) return node
        }
        return null
    }

    private fun findNodeByText(root: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? =
        root.findAccessibilityNodeInfosByText(text)?.firstOrNull { it.isClickable }

    private fun findNodeByContentDesc(root: AccessibilityNodeInfo, desc: String): AccessibilityNodeInfo? {
        if (root.contentDescription?.toString()?.lowercase()?.contains(desc) == true) return root
        for (i in 0 until root.childCount) {
            val result = findNodeByContentDesc(root.getChild(i) ?: continue, desc)
            if (result != null) return result
        }
        return null
    }

    private fun collectAllNodeText(root: AccessibilityNodeInfo): List<String> {
        val texts = mutableListOf<String>()
        root.text?.toString()?.let { if (it.isNotEmpty()) texts.add(it) }
        root.contentDescription?.toString()?.let { if (it.isNotEmpty()) texts.add(it) }
        for (i in 0 until root.childCount) {
            texts.addAll(collectAllNodeText(root.getChild(i) ?: continue))
        }
        return texts
    }

    private fun isCallEnded(windowText: String): Boolean =
        listOf("call ended", "call disconnected", "missed call").any { windowText.contains(it) }

    private fun broadcastSimpleStatus(status: String) {
        sendBroadcast(Intent("com.priya.autoresponder.STATUS_UPDATE").apply {
            `package` = packageName
            putExtra("status", status)
        })
    }

    private fun broadcastCallAnswered() {
        sendBroadcast(Intent(ACTION_CALL_ANSWERED).apply { `package` = packageName })
        startForegroundService(
            Intent(this, CallProcessingService::class.java)
                .apply { action = ACTION_CALL_ANSWERED }
        )
    }

    private fun broadcastCallEnded() {
        sendBroadcast(Intent(ACTION_CALL_ENDED).apply { `package` = packageName })
        startService(
            Intent(this, CallProcessingService::class.java)
                .apply { action = ACTION_CALL_ENDED }
        )
    }

    override fun onInterrupt() {
        Log.i(TAG, "Accessibility service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "Accessibility service destroyed")
    }
}

object AppPreferencesAccessor {
    fun getAnswerDelayMs(service: AccessibilityService): Long {
        val prefs = service.getSharedPreferences("priya_prefs", android.content.Context.MODE_PRIVATE)
        return prefs.getInt("answer_delay", 2) * 1000L
    }
}
