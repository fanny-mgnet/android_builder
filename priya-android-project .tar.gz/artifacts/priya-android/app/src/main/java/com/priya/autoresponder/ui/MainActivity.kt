package com.priya.autoresponder.ui

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
import androidx.core.content.ContextCompat.registerReceiver
import com.priya.autoresponder.AppPreferences
import com.priya.autoresponder.databinding.ActivityMainBinding
import com.priya.autoresponder.services.CallProcessingService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var tts: TextToSpeech? = null
    private val logBuilder = StringBuilder()
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val status = intent?.getStringExtra(CallProcessingService.EXTRA_STATUS) ?: return
            val text = intent.getStringExtra(CallProcessingService.EXTRA_TEXT) ?: ""
            runOnUiThread {
                updateStatusDisplay(status, text)
            }
        }
    }

    private val requiredPermissions = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClickListeners()
        loadSavedApiKey()
        requestRequiredPermissions()
    }

    override fun onResume() {
        super.onResume()
        updateAccessibilityStatus()
        registerReceiver(
            this,
            statusReceiver,
            IntentFilter(CallProcessingService.ACTION_STATUS),
            RECEIVER_NOT_EXPORTED
        )
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(statusReceiver)
        } catch (e: IllegalArgumentException) { /* not registered */ }
    }

    private fun setupClickListeners() {
        binding.btnEnableAccessibility.setOnClickListener {
            openAccessibilitySettings()
        }

        binding.btnGetApiKey.setOnClickListener {
            val uri = Uri.parse("https://console.groq.com/keys")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }

        binding.btnSaveApiKey.setOnClickListener {
            val key = binding.etApiKey.text?.toString()?.trim() ?: ""
            if (key.isBlank()) {
                Toast.makeText(this, "Please enter your Groq API key", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            AppPreferences.setGroqApiKey(this, key)
            Toast.makeText(this, "API key saved!", Toast.LENGTH_SHORT).show()
            addLog("✅ API key configured")
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnTestTts.setOnClickListener {
            testPriyaVoice()
        }

        binding.btnClearLog.setOnClickListener {
            logBuilder.clear()
            binding.tvActivityLog.text = "Log cleared."
        }
    }

    private fun loadSavedApiKey() {
        val key = AppPreferences.getGroqApiKey(this)
        if (key.isNotBlank()) {
            binding.etApiKey.setText(key)
        }
    }

    private fun updateAccessibilityStatus() {
        val isEnabled = isAccessibilityServiceEnabled()
        if (isEnabled) {
            binding.tvAccessibilityStatus.text = "✅ Enabled — Priya is watching for calls"
            binding.tvAccessibilityStatus.setTextColor(getColor(android.R.color.holo_green_light))
            binding.tvStatus.text = "Active — watching for WhatsApp calls"
        } else {
            binding.tvAccessibilityStatus.text = "❌ Not enabled — tap button below"
            binding.tvAccessibilityStatus.setTextColor(getColor(android.R.color.holo_red_light))
            binding.tvStatus.text = "Inactive"
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        )
        return enabledServices.any {
            it.resolveInfo.serviceInfo.packageName == packageName
        }
    }

    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
        Toast.makeText(
            this,
            "Find 'Priya Auto Responder' and enable it",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun updateStatusDisplay(status: String, text: String) {
        val statusLabel = when (status) {
            "incoming_call" -> "📞 Incoming call detected"
            "recording"     -> "🎙 Recording caller…"
            "transcribing"  -> "📝 Transcribing…"
            "transcribed"   -> "📝 $text"
            "generating"    -> "🤔 Generating response…"
            "speaking"      -> "🔊 $text"
            "error"         -> "❌ Error: $text"
            "idle"          -> "✅ Call ended"
            else            -> text
        }
        binding.tvStatus.text = statusLabel
        addLog("[${timeFormat.format(Date())}] $statusLabel")
    }

    private fun addLog(message: String) {
        if (logBuilder.isNotEmpty()) logBuilder.append("\n")
        logBuilder.append(message)
        binding.tvActivityLog.text = logBuilder.toString()
    }

    private fun testPriyaVoice() {
        tts?.shutdown()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                tts?.setSpeechRate(0.9f)
                tts?.speak(
                    "Hello! This is Priya. How can I help you today?",
                    TextToSpeech.QUEUE_FLUSH,
                    null,
                    "test"
                )
                addLog("🔊 Testing Priya's voice")
            }
        }
    }

    private fun requestRequiredPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            val denied = permissions.zip(grantResults.toList())
                .filter { it.second != PackageManager.PERMISSION_GRANTED }
                .map { it.first }
            if (denied.isNotEmpty()) {
                addLog("⚠️ Missing permissions: ${denied.joinToString()}")
            } else {
                addLog("✅ All permissions granted")
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.shutdown()
    }
}
