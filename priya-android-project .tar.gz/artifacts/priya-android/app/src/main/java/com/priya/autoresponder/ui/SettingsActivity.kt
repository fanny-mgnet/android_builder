package com.priya.autoresponder.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.priya.autoresponder.AppPreferences
import com.priya.autoresponder.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.apply {
            title = "Advanced Settings"
            setDisplayHomeAsUpEnabled(true)
        }

        loadCurrentSettings()
        setupClickListeners()
    }

    private fun loadCurrentSettings() {
        binding.etPersonality.setText(AppPreferences.getPersonality(this))
        binding.etAnswerDelay.setText(AppPreferences.getAnswerDelay(this).toString())
        binding.etListenDuration.setText(AppPreferences.getListenDuration(this).toString())
        binding.etLlmModel.setText(AppPreferences.getLlmModel(this))
        binding.etSttModel.setText(AppPreferences.getSttModel(this))
    }

    private fun setupClickListeners() {
        binding.btnSaveSettings.setOnClickListener {
            saveSettings()
        }
    }

    private fun saveSettings() {
        val personality = binding.etPersonality.text?.toString()?.trim() ?: ""
        val answerDelayStr = binding.etAnswerDelay.text?.toString()?.trim() ?: "2"
        val listenDurationStr = binding.etListenDuration.text?.toString()?.trim() ?: "8"
        val llmModel = binding.etLlmModel.text?.toString()?.trim() ?: ""
        val sttModel = binding.etSttModel.text?.toString()?.trim() ?: ""

        if (personality.isNotBlank()) AppPreferences.setPersonality(this, personality)

        val answerDelay = answerDelayStr.toIntOrNull()
        if (answerDelay != null && answerDelay in 0..10) {
            AppPreferences.setAnswerDelay(this, answerDelay)
        } else {
            Toast.makeText(this, "Answer delay must be 0–10 seconds", Toast.LENGTH_SHORT).show()
            return
        }

        val listenDuration = listenDurationStr.toIntOrNull()
        if (listenDuration != null && listenDuration in 3..30) {
            AppPreferences.setListenDuration(this, listenDuration)
        } else {
            Toast.makeText(this, "Listen duration must be 3–30 seconds", Toast.LENGTH_SHORT).show()
            return
        }

        if (llmModel.isNotBlank()) AppPreferences.setLlmModel(this, llmModel)
        if (sttModel.isNotBlank()) AppPreferences.setSttModel(this, sttModel)

        Toast.makeText(this, "Settings saved!", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
